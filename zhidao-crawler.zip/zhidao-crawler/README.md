## How to use
`pip3 install scrapy`

在项目根目录下执行`scrapy crawl olay -a key="key_words" -a amount=question_amount`.

爬取结果会输出到scraped_data_utf8.jl文件中.
