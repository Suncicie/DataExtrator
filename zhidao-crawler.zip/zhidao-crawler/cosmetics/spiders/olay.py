# -*- coding: utf-8 -*-
import scrapy
import re


class OlaySpider(scrapy.Spider):
    name = 'olay'
    allowed_domains = ['zhidao.baidu.com']

    def start_requests(self):
        key_word = getattr(self, 'key', '玉兰油')
        amount = int(getattr(self, 'amount', 0))
        urls = ['https://zhidao.baidu.com/search?lm=0&rn=10&pn=0&fr=search&ie=gbk&word=%s' % key_word] + \
            ['https://zhidao.baidu.com/search?word=%s&ie=gbk&site=-1&sites=0&date=0&pn=%d' %
                (key_word, i) for i in range(10, amount, 10)]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        for href in response.css('dt.dt.mb-4.line a::attr(href)').extract():
            if href is not None:
                yield scrapy.Request(href, callback=self.parse_qa)

    def best_answer(self, response):
        best_answer_strings = response.css(
            'pre.best-text.mb-10::text').extract()
        if best_answer_strings == []:
            return None
        best_answer_evaluates = response.css(
            'div.wgt-best.mod-shadow div.qb-zan-eva span.iknow-qb_home_icons.evaluate.evaluate-32::attr(data-evaluate)').extract()

        best_answer = {'content': ''.join(best_answer_strings),
                       'tag': 'best',
                       'commend': int(best_answer_evaluates[0] or 0),
                       'oppose': int(best_answer_evaluates[1] or 0)}

        return best_answer

    def parse_qa(self, response):
        best_answer = self.best_answer(response)

        def remove_tags(str): return re.sub('<.*?>', '', str)
        answers_html = response.css(
            'div.bd.answer div.answer-text span.con, div.bd.answer div.answer-text p').extract()
        answer_texts = list(map(remove_tags, answers_html))
        evaluates = response.css(
            'div.bd-wrap div.qb-zan-eva span.iknow-qb_home_icons.evaluate.evaluate-32::attr(data-evaluate)').extract()

        # chunk[0] is commend amount, chunk[1] is oppose amount.
        evaluates_chunk = [evaluates[i: i + 2]
                           for i in range(0, len(evaluates), 2)]
        answers = []
        if (len(answer_texts) > 0):
            for text, evaluate in zip(answer_texts, evaluates_chunk):
                answers.append({
                    'content': text,
                    'tag': 'common',
                    'commend': int(evaluate[0]),
                    'oppose': int(evaluate[1])
                })

        yield {
            'question': response.css('span.ask-title::text').extract_first(),
            'answers': [best_answer] + answers
        }
