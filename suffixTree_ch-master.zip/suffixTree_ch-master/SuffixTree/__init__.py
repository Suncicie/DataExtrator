from SubstringDict import SubstringDict
from SuffixTree import *
